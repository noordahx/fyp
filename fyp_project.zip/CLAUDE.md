# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a differential privacy research framework that implements membership inference attacks (MIA) and differential privacy (DP) training methods. The project evaluates privacy-utility tradeoffs in machine learning models trained with various DP techniques.

## Core Architecture

### Main Components
- **Training Pipeline** (`src/train/`): DP training methods including DP-SGD, Output Perturbation
- **Attack Framework** (`src/attacks/`): MIA implementations including Shadow, Loss-based, Threshold, and Population attacks
- **Model Factory** (`src/models.py`): ResNet-based architectures for CIFAR-10/100 and MNIST
- **Data Pipeline** (`src/data.py`): Dataset loaders with privacy-aware splits
- **Utilities** (`src/new_utils/`): Configuration management, metrics, and visualization tools

### Configuration System
- YAML-based configuration in `configs/` directory
- Hierarchical config structure: model, data, attack, defense, training, output sections
- Config objects use dataclasses in `src/new_utils/config.py`
- Three main configs: `simple_config.yaml`, `full_config.yaml`, `default.yaml`

### Key Design Patterns
- **Abstract Base Classes**: All attacks inherit from `BaseAttack` in `src/attacks/base.py`
- **Factory Pattern**: Attack selection via `get_attack_by_name()`, DP method selection via `get_dp_method()`
- **Config-driven**: All parameters controlled through YAML configs rather than hardcoded values
- **Modular DP Methods**: Each DP technique implemented as separate class in `src/train/dp_methods.py`

## Common Development Commands

### Training Models
```bash
# Train with differential privacy
python scripts/train.py --config configs/simple_config.yaml --method dp_sgd_custom --output_dir ./results

# Train standard (non-private) baseline
python scripts/train.py --config configs/simple_config.yaml --method standard

# Train with output perturbation
python scripts/train.py --config configs/simple_config.yaml --method output_perturbation
```

### Running Membership Inference Attacks
```bash
# Run all attacks on a trained model
python scripts/attack.py --config configs/simple_config.yaml --model results/cifar10_standard_eps3.0.pt --attack shadow

# Run specific attack types
python scripts/attack.py --config configs/simple_config.yaml --model results/model.pt --attack loss
python scripts/attack.py --config configs/simple_config.yaml --model results/model.pt --attack population
```

### Development Utilities
```bash
# Clean temporary files
make clean

# Create project archive
make zip

# View available commands
make help
```

## Configuration Management

### Key Config Sections
- `model`: Architecture (resnet18), num_classes, pretrained weights, dropout
- `data`: Dataset (cifar10/cifar100/mnist), batch sizes, num_workers  
- `defense`: DP method, epsilon, delta, gradient clipping parameters
- `attack`: Attack type, features to extract, attack-specific hyperparameters
- `training`: Epochs, learning rate, optimization parameters
- `output`: Save directories, visualization settings

### Override Patterns
- Command-line args override config values (e.g., `--method` overrides `config.defense.method`)
- Config files can be specialized for different experiments (simple vs full vs default)

## File Organization

### Active Source Code
- `scripts/`: Main entry points for training and attacking
- `src/attacks/`: MIA implementations - each attack type in separate file
- `src/train/`: DP training orchestration and method implementations  
- `src/new_utils/`: Shared utilities for config, data, metrics, visualization
- `configs/`: YAML configuration files for different experiment setups

### Results and Data
- `results/`: Trained model checkpoints and training plots
- `data/`: Downloaded datasets (MNIST, CIFAR-10/100)
- `ignore/`: Archived/moved old implementations and demo reports

### Key Dependencies
- PyTorch for ML training and inference
- Opacus for DP-SGD implementation  
- scikit-learn for attack model training (Random Forest, etc.)
- matplotlib/seaborn for visualization
- YAML for configuration management

## Development Notes

### Privacy Methods Available
- `standard`: No privacy (baseline)
- `dp_sgd_custom`: Custom DP-SGD with gradient clipping and noise
- `output_perturbation`: Post-training noise addition to outputs

### Attack Types Available  
- `shadow`: Train shadow models to learn membership patterns (most sophisticated)
- `loss`: Use model loss values to infer membership (very effective)
- `threshold`: Simple confidence threshold attack (baseline)
- `population`: Compare against reference model statistics

### Model Training Flow
1. Load config from YAML → `src/new_utils/config.py`
2. Create dataset loaders → `src/data.py`
3. Initialize model architecture → `src/models.py`  
4. Select DP method → `src/train/dp_methods.py`
5. Train with orchestrator → `src/train/dp_training.py`
6. Save model + metrics + visualizations

### Attack Evaluation Flow
1. Load trained target model and config
2. Split data into attack training/testing sets
3. Extract features (predictions, losses, etc.)
4. Train attack classifier (if needed)
5. Evaluate membership inference performance (AUC, accuracy)
6. Generate performance visualizations and reports